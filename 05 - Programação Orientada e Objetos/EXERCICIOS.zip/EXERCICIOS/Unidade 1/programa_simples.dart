void main() {
  // Declaração da variável
  int numero = 10;

  // Exibindo o valor da variável no console
  print('O valor da variável numero é: $numero');
}
