void main() {
  int a = 10;
  int b = 3;

  print("Soma: ${a + b}");
  print("Subtração: ${a - b}");
  print("Multiplicação: ${a * b}");
  print("Divisão: ${a / b}");
  print("Resto: ${a % b}");
}
