void main() {
  int a = 5;
  int b = 10;

  print(a == b); // false
  print(a != b); // true
  print(a < b); // true
  print(a >= b); // false
}
