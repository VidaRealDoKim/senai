void main() {
  bool a = true;
  bool b = false;

  print(a && b); // false

  print(!a); // false
}
