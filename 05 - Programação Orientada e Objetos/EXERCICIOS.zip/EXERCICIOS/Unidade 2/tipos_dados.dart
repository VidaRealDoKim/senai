void main() {
  int idade = 25; // Tipo int
  double altura = 1.75; // Tipo double
  String nome = "João"; // Tipo String
  bool estaChovendo = true; // Tipo bool

  print(
    "Nome: $nome, Idade: $idade, Altura: $altura, Está chovendo? $estaChovendo",
  );
}
